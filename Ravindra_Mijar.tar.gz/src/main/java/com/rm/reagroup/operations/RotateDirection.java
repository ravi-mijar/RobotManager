package com.rm.reagroup.operations;

/**
 * This enum will hold the possible directions of rotation of the robot.
 * @author hawk
 *
 */
public enum RotateDirection {
	LEFT, RIGHT;
}
