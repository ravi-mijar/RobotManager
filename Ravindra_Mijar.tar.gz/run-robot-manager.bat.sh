#this script will run the RobotManager Application
java -jar target/RobotManager-0.0.1-SNAPSHOT-jar-with-dependencies.jar